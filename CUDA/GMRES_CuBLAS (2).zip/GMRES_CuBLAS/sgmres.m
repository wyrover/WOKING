% SGMRES 
% A simpler implementation [1] of the GMRES method [2] with adaptive basis [3]
%
% Created by Pavel Jiranek, 13/12/2008
%
% WWW:    http://flow.kmo.tul.cz/~paya
%         http://www.google.com/search?q=pavel+jiranek
%
% E-mail: pavel.jiranek@tul.cz
%
% If you find a BUG, please LET ME KNOW! Thank you.
%
% X = SGMRES(A,B) 
% attempts to solve the system of linear equations A* X = B for X. The NxN
% coefficient matrix must be square and the right-hand side column vector
% must have length N. The parameter A can be a MATLAB function as well.
% In such case A(V) gets the N-vector V and returns the product A * V.
%
% X = SGMRES(A,B,M) specifies the right preconditioner M, that is, the algorithm
% attempts to solve the right-preconditioned system A * inv(M) * Y = B, where
% Y = M * X. The preconditioner is applied via the backslash operator \.
% For more general preconditioners, M can be also specified as a MATLAB function
% M(V) returning a preconditioning operator applied to a vector V. If M = []
% (default) no preconditioner is used.
%
% X = SGMRES(A,B,M,X0) specifies the initial guess. If X0 = [] (default) the
% zero vector is used.
%
% X = SGMRES(A,B,M,X0,OPTS) specified the additional options. Each of them has
% its default value which is used if not specified (see below). The structure
% OPTS has the following fields:
%  - maxit (default N) specifies the maximum number of iterations.
%  - restart (default N) specifies the restart parameter -- the maximum 
%    dimension of the Krylov subspace.
%  - tol (default 1e-5) specifies the tolerance in the stopping criterion.
%    The iteration is stopped if
%
%    |r| <= tol * (OPTS.tolc(1) |A| |x| + OPTS.tolc(2) |b| + OPTS.tolc(3)).
%
%  - tolc (default [0, 1, 0]) specifies parameters for the stopping
%    criterion. The most usual values are
%    [0, 1, 0]: checking of the relative residual norm,
%    [1, 1, 0]: checking of the normwise backward error,
%    [0, 0, 1]: checking of the absolute residual norm.
%  - nu (default 0.9) specifies the parameter for the adaptive Simpler GMRES,
%    see [3] for more details.
%
% References:
%
% [1] H. F. Walker, L. Zhou, A simpler GMRES, Numer. Linear Algebra Appl., 
%     1 (1994), p. 571--581.
%
% [2] Y. Saad, M. H. Schultz, GMRES: A generalized minimal residual algorithm
%     for solving nonsymmetric linear systems, SIAM J. Sci. Comput., 7 (1986),
%     pp. 856--869
%
% [3] P. Jiranek, M. Rozloznik, Adaptive version of Simpler GMRES, Tech. Rep.
%     TR/PA/08/101, CERFACS, 2008.
%
function [x] = sgmres(A, b, x0, opts);

% check the number of input arguments
if nargin < 2
  error('Not enough input arguments.');
end

% get the dimension from B
N = size(b,1);

% check the dimensions
if size(b,2) > 1
  error('Multiple right-hand sides are not supported.');
end
if ~isa(A, 'function_handle') % A is not a function
  % check the dimensions of A
  if (size(A, 1) ~= N) | (size(A, 2) ~= N)
    error('Matrix A must be square and conforming B.');
  end
end

% create default (or empty) parameters
if nargin < 5, opts = []; end;
if nargin < 4, x0 = []; end;
if nargin < 3, M = []; end;

% fill OPTS with default values if not specified
if ~isfield(opts, 'maxit'), opts.maxit = N; end;
if ~isfield(opts, 'restart'), opts.restart = N; end;
if ~isfield(opts, 'tol'), opts.tol = 1e-5; end;
if ~isfield(opts, 'nu'), opts.nu = 0.9; end;
if ~isfield(opts, 'tolc'), opts.tolc = [0,1,0]; end

% set default parameters
if isempty(x0), x0 = zeros(N, 1); end;
%if isempty(M),  M = @ident; end;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%% HERE STARTS THE CODE %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% initialization
x = x0;
nrm_b = norm(b); nrm_a = 0; % norm of B and estimate on the norm of A
flags = inf; iter = 1; resvec = [];

% allocate data
Z = zeros(N, opts.restart);
V = zeros(N, opts.restart);
U = zeros(opts.restart, opts.restart);
alph = zeros(opts.restart, 1);

% outer loop
while 1
  r = b - A * x; % get the residual
  nrm_x = norm(x);
  
  % inner loop
  for n = 1 : opts.restart
    resvec(iter) = norm(r); % compute the residual norm
    stop_rhs = opts.tolc(1) * nrm_a * nrm_x ...
             + opts.tolc(2) * nrm_b ...
             + opts.tolc(3);
    stop_rhs = opts.tol * stop_rhs;
    if resvec(end) <= stop_rhs
      flags = 0;
      n = n - 1;
      break;
    end
    if iter >= opts.maxit % check the maximum number of iterations
      flags = 1;
      n = n - 1;
      break;
    end
    if n == 1
      Z(:,1) = r;
    else
      if resvec(end) <= opts.nu * resvec(end-1)
        Z(:,n) = r;
      else
        Z(:,n) = V(:,n-1);
      end
    end
    Z(:,n) = Z(:,n) / norm(Z(:,n));
    V(:,n) = amul(A, Z(:,n));
    for k = 1 : n - 1
      U(k,n) = V(:,k)' * V(:,n);
      V(:,n) = V(:,n) - U(k,n) * V(:,k);
    end
    U(n,n) = norm(V(:,n));
    V(:,n) = V(:,n) / U(n,n);
    alph(n, 1) = V(:,n)' * r;
    r = r - V(:,n) * alph(n, 1);
    iter = iter + 1; % update inner-outer iteration number
  end
  x = x + Z(:,1:n) * (U(1:n,1:n) \ alph(1:n,1)); % compute the approximation
  nrm_a = max(nrm_a, norm(U(1:n,1:n))); % stupid estimate of norm(A)
  if flags < inf, break; end; % break if FLAGS is set
end
iter = iter - 1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%% HERE ENDS THE CODE %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function y = amul(A,x) % returns Y = A * X

if isa(A, 'function_handle')
  y = A(x);
else
  y = A * x;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function y = mmul(M,x) % returns Y = M \ x

if isa(M, 'function_handle')
  y = M(x);
else
  y = M \ x;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function y = ident(x) % returns y = x

y = x;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

