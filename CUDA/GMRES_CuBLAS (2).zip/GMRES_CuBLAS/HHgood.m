function [v,tau] = HHgood(a);
%
%  Input:   a  -  an m  vector
%
%  Output:  v,tau -  
%                 The Householder Transformatin is  I - tau*v*v'
%
%  Demonstrates results of correct sign choice in HH transformation
%
%  D.C. Sorensen 
%  15 Sep 04
%-----------------------------------------------------------------

     m = length(a);
     e1 = eye(m,1);

%
%    Compute the Householder vector v
%
%    I - tau(k)*v*v' is the transformation 
%
     v = a;
%
%    Correct Choice of Sign !!!
%
     rho = -sign(v(1))*norm(v);

     if (abs(rho) > 0),
        v(1) = v(1) - rho;
        tau = -v(1)/rho;
        v = v/v(1);
     end

     w = a - v*(tau*v'*a);

     disp('Diff = norm(e1*rho - w)')
     Diff = norm(e1*rho - w)
